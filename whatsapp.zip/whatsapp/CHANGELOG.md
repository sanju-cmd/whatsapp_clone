## CHANGELOG ##


> All changes will be documented in this file

### [0.0.2] - 2019-03-15

### Added
- Added new option to `Back Home` in chat

### Changed

### Fixed
**BUG**<br/>
`getAllMessages function` in `function.php`<br/>



> Displays in the chat list, all contacts and messages sent to another user

**Fixed**<br/>
`getAllMessages function` in `function.php`,



> Display in the chat list, only chat partners

### [0.0.1] - 2019-03-15

### Added
- Added `CHANGELOG.md`.
